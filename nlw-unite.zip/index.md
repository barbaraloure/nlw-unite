fronteditor.dev/nlw-unite

# HTML
*HiperText*
links
*markup*
tags
*lunguage*

# CSS

#JavaScrip
```js
// variáveis
   const mensagem = `oi, tudo bem?`
   var
   let
// Tipos de Dados 
    // Number
    // string
    //Booleno
// Funçao
alert(mensagem) 
// função tem que;
// pegar informação do HTML
// e substituir informação do HTML

// objeto javaScript
const participante = {
  nome: "Mayk Brito",
  email: "maykbrito.com",
  dataInscricao: new Date(2024, 2, 22, 19, 20),
  dataCheckIn: new Date(2024, 2, 25, 22, 00)
}
//lista de participantes
//array
let participantes = [
  { 
    nome: "Mayk Brito",
    email: "maykbrito.com",
    dataInscricao: new Date(2024, 2, 22, 19, 20),
    dataCheckIn: new Date(2024, 2, 25, 22, 00)
  },
] 


 for(let participante of participantes) {
  //faça alguma coisa aki
  // enaquanto tiver participantes nessa lista
  }
```    


  